#!/bin/bash
sleep 10;
touch uno_acabo.txt;
exit 0;